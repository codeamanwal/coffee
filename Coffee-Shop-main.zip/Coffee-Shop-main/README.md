# Coffee-Shop
An e-commerce platform to order coffee.
Techstack - HTML, CSS, JS, REACT JS, AJAX.

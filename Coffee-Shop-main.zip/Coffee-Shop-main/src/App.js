import Shop from './components/Shop'

function App(){
  return (
    <div>
      <Shop />
    </div>
  );
}

export default App;
